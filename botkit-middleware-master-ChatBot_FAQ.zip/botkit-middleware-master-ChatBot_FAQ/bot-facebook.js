/**
 * Copyright 2016 IBM Corp. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

require('dotenv').load();

var Botkit = require('botkit');

var request = require('request');

var Client = require('node-rest-client').Client;

var client = new Client();

var dateTime = require('node-datetime');

var airports = require('airport-codes');

var index = require('airportsjs');

var ssll = require('ssl-root-cas').inject();

var middleware = require('botkit-middleware-watson')({
	username: process.env.CONVERSATION_USERNAME,
	password: process.env.CONVERSATION_PASSWORD,
	workspace_id: process.env.WORKSPACE_ID,
	url: process.env.CONVERSATION_URL || 'https://gateway-lon.watsonplatform.net/assistant/api',
	version_date: '2017-05-26'
  });
  

var controller = Botkit.facebookbot({
  access_token: process.env.FB_ACCESS_TOKEN,
  verify_token: process.env.FB_VERIFY_TOKEN
});

var bot = controller.spawn();

function isDefined(obj) {
	if (typeof obj == 'undefined') {
		return false;
	}

	if (!obj) {
		return false;
	}

	return obj != null;
}

var airportCodeMap = null;

if(airportCodeMap == null){
	airportCodeMap = {};

	var fs = require("fs");
	var fileOutput =  fs.readFileSync("airport.json");
	var jsonContent = JSON.parse(fileOutput);
	
	for(x in jsonContent){
		//console.log(jsonContent[x]['city']);
		var cityName = jsonContent[x]['city'].toLowerCase();
		if(airportCodeMap[cityName] == undefined){
			var list = [];	 
			list.push(jsonContent[x]);
			airportCodeMap[cityName] = list;
		}else{
			var list = airportCodeMap[cityName];
			list.push( jsonContent[x]);
			airportCodeMap[cityName] = list;
		}
	}

}


console.log(airportCodeMap['delhi'][0]['iata']);

controller.hears('(.*)', 'message_received', function(bot, message) {
    //console.log("Env file takennnn" +process.env.CONVERSATION_URL);
	console.log(message);
	// console.log(controller.)
	var textMessage =  message.watsonData.output.text.join("\n");
	
	var quickReplies = false;
	
	if(textMessage.indexOf("_option_") != -1){
		textMessage = textMessage.replace("_option_","");
		quickReplies = true;
	}

	var type= "";

	var checkInReplies = false;
	if(textMessage.indexOf("_checkin_") != -1){
		textMessage = textMessage.replace("_checkin_","");
		type = "ShowCheckIn";
	}

	var proceedCheckIn = false;
	if(textMessage.indexOf("_proceedcheckin_") != -1){
		textMessage = textMessage.replace("_proceedcheckin_","");
		type = "ProceedCheckIn";
	}


	var flightDetails = false;
	if(textMessage.indexOf("_flightDetails_") != -1){
		textMessage = textMessage.replace("_flightDetails_","");
		type = "flightDetails";
	}
	
	
	var quickRepliesForFAQ = false;
	if(textMessage.indexOf("_FAQ_") != -1){
		textMessage = textMessage.replace("_FAQ_","");
		quickRepliesForFAQ = true;
	}

	
	var quickRepliesForShare = false;
	if(textMessage.indexOf("_shareNow_") != -1){
		textMessage = textMessage.replace("_shareNow_","");
		type="shareNow";
		quickRepliesForShare = true;
	}

	var quickRepliesForyesno = false;
	if(textMessage.indexOf("_yesNo_") != -1){
		textMessage = textMessage.replace("_yesNo_","");
		type = "yesNo";
		quickRepliesForyesno = true;
	}
	
	var sharetoWhatsapp = false;
	if(textMessage.indexOf("_shareWhatsapp_") != -1){
		textMessage = textMessage.replace("_shareWhatsapp_","");
		type = "ShareToWhatsapp";
	}
	
	var sharetoEmail = false;
	if(textMessage.indexOf("_shareEmail_") != -1){
		textMessage = textMessage.replace("_shareEmail_","");
		type = "ShareToEmail";
	}
	
	
	var messageData = {
		recipient: {
			id: message.channel
		},
		message: {
			text: textMessage,
			
		}
	};

	if(quickReplies == true){
		messageData.message.quick_replies = createQuickReplies();
	}else if(quickRepliesForFAQ == true){
		messageData.message.quick_replies = createQuickRepliesForFAQ();
	}else if(quickRepliesForyesno == true){
		messageData.message.quick_replies = createQuickRepliesForyesno();
	}

	//if(checkInReplies == true){
	//	messageData.message.attachement = createAirlineItenrarySample();
	//}
	//console.log(messageData);
 //bot.reply(message, message.watsonData.output.text.join("\n"));
	callSendAPI(messageData);

	parseMessage(message, type, bot);
	
});


function createQuickReplies(){
	let quick_replies = [
			/*{
				"content_type":"text",
				"title":"Search Flight",
				"payload":"1"
			},*/
			{
				"content_type":"text",
				"title":"CheckIn Flight",
				"payload":"1"
			},
			{
				"content_type":"text",
				"title":"FAQ's",
				"payload":"2"
			}
			/*,
			{
				"content_type":"text",
				"title":"Book Flight",
				"payload":"3"
			},*/
	]

	return quick_replies;
}

function createQuickRepliesForCheckIn(){
	let checkInReplies = [
			{
				"content_type":"text",
				"title":"Proceed Check-In",
				"payload":"1"
			},
			{
				"content_type":"text",
				"title":"Later",
				"payload":"2"
			}
	
	]

	return checkInReplies;
}

function createQuickRepliesForFAQ(){
	let faqReplies = [
			{
				"content_type":"text",
				"title":"Baggage Allowance",
				"payload":"1"
			},
			{
				"content_type":"text",
				"title":"Baby Travel",
				"payload":"2"
			},
			{
				"content_type":"text",
				"title":"Airport Details",
				"payload":"3"
			},
			{
				"content_type":"text",
				"title":"Enter your queries",
				"payload":"4"
			}
	]

	return faqReplies;
}


function createQuickRepliesForShare(){
	let shareReplies = [
		{
			"content_type":"text",
			"title":"Share On WhatsApp",
			"payload":"1"
		},
		{
			"content_type":"text",
			"title":"Share On Email",
			"payload":"2"
		},
		{
			"content_type":"text",
			"title":"No, I don't want to share",
			"payload":"3"
		}
	]

return shareReplies;
}


function createQuickRepliesForyesno(){
	let yesnoReplies = [
		{
			"content_type":"text",
			"title":"Yes",
			"payload":"1"
		},
		{
			"content_type":"text",
			"title":"No",
			"payload":"2"
		}
	]

return yesnoReplies;
}


var departure = "";
var destination = "";

function parseMessage(message, type, bot){
	console.log(type);
	if(type === "flightDetails"){
				//console.log(message.watsonData.context["fetchDetails"]);

				departure = message.watsonData.context["destination"];
				 destination = message.watsonData.context["arrival"];
				var date = message.watsonData.context["flightdate"];
				
			
				var departureAirportCode = airportCodeMap[departure.toLowerCase()][0]['iata'];
				var destinationAirportCode = airportCodeMap[destination.toLowerCase()][0]['iata'];
				
				//console.log(departureAirportCode);
				//console.log(destinationAirportCode);

				sendTypingOn(message.channel);
		
				callAPI(departureAirportCode, destinationAirportCode ,date, message.channel);

		//	console.log(airports.findWhere({'city':'Delhi'}).get('name'));
		 //console.log(	airports.findWhere({'city':'Delhi'}).get('iata'));
		
				
				sendTypingOff(message.channel);

	}else if(type === "ShowCheckIn"){
		//console.log("message" + message);
		sendTypingOn(message.channel);
		createItinerayTemplate(message.watsonData.context["pnrnumber"],message.watsonData.context["person"],message);
		sendTypingOff(message.channel);
		
	}else if (type === "ProceedCheckIn"){
				
		var tranid = message.watsonData.context["tranid"];
		var passengerInfo = message.watsonData.context["passengerArray"];
		
		sendTypingOn(message.channel);
		createBoardingPassTemplate(tranid,passengerInfo,message.channel);
		sendTypingOff(message.channel);
		
	}else if(type === "ShareToWhatsapp"){
		var tranid = message.watsonData.context["tranid"];
		var paxArray = message.watsonData.context["passengerArray"];
		var flightArray= message.watsonData.context["flightArray"];
		var phNumber = message.watsonData.context["phoneNumber"];
		sendTypingOn(message.channel);
		shareBoardingPassToWhatsapp(phNumber,paxArray,flightArray,tranid,message.channel);
		sendTypingOff(message.channel);
	}else if(type === "ShareToEmail"){
		var tranid = message.watsonData.context["tranid"];
		var paxArray = message.watsonData.context["passengerArray"];
		var flightArray= message.watsonData.context["flightArray"];
		var emailId = message.watsonData.context["emailId"];
		sendTypingOn(message.channel);
		shareBoardingPassToEmail(emailId,paxArray,flightArray,tranid,message.channel);
		sendTypingOff(message.channel);
	}
}

function sendTypingOff(recipientId) {


	var messageData = {
		recipient: {
			id: recipientId
		},
		sender_action: "typing_off"
	};

	callSendAPI(messageData);
}

function sendTypingOn(recipientId) {


	var messageData = {
		recipient: {
			id: recipientId
		},
		sender_action: "typing_on"
	};

	callSendAPI(messageData);
}


function createListTemplate(){
	let attachment = {
		type : "template",
		payload : {
		 template_type:"list",
		 top_element_style:"compact",
		 elements:[{
		       title :"London To Delhi",
			   subtitle :" Flight From",
			   image_url:"http://localhost:8080/test.png"
		 	},
		 	{
			       title :"Flight Details",
			       subtitle :" Flight From",
				   image_url:"http://localhost:8080/test.png"
			 	}
		 ]
	
			
		}
	};
	
	return attachment;
}

function getAirportCode(city){
	

	request({
		uri: 'https://iatacodes.org/api/v6/cities',
		qs: {
			api_key: '4b210468-a0e0-4108-ba29-a9394a50c012',
			cities:city.toLowerCase()
		},
		method: 'GET',
		"rejectUnauthorized": false,
		"strictSSL": false
	

	}, function (error, response, body) {
		if (!error && response.statusCode == 200) {
			//console.log(response.body.response);
			return response.airports_by_cities[0].code;
		} else {
			//console.error("Failed calling Send API", error);
		}
	});
}


function callSendAPI(messageData) {
	//console.log(messageData.message.quick_replies);
	request({
		uri: 'https://graph.facebook.com/v2.6/me/messages',
		qs: {
			access_token: process.env.FB_ACCESS_TOKEN
		},
		method: 'POST',
		json: messageData

	}, function (error, response, body) {
		//console.log(" Error " +error);
		//console.log(" response.statusCode" + response.statusCode);
		if (!error && response.statusCode == 200) {
			var recipientId = body.recipient_id;
			var messageId = body.message_id;
			if (messageId) {
				console.log("Successfully sent message with id %s to recipient %s",
					messageId, recipientId);
			} else {
				console.log("Successfully called Send API for recipient %s",
					recipientId);
			}
		} else {
			console.error("Failed calling Send API", error);
		}
	});
}

module.exports.controller = controller;
module.exports.bot = bot;


function callAPI(departure,destination,date,channel){
//	console.log(date);
	request({
		uri: 'https://www.googleapis.com/qpxExpress/v1/trips/search',
		qs: {
			key: 'AIzaSyDhYPI7XWhGGg3Rvj-40iiRID6ma5uFMmA'
		},
		method: 'POST',
		contentType:'application/json',
		json: createFlightRequest(departure,destination,date)

	}, function (error, response, body) {
		//console.log(response);
	//	console.log( body);
		if (!error && response.statusCode == 200) {
			var recipientId = body.recipient_id;
			var messageId = body.message_id;
			//console.log(body.trips);Fa
			//console.log(body.trips.data.airport);
			
			
			createAttachment(response.body.trips,channel);
			
		} else {
			console.error("Failed calling qPX Express API", error);
		}
	});
}

function createAttachment(trips,channel){


 var flightElements = [];
 //console.log(trips.tripOption)
	if(trips.tripOption != undefined){
		trips.tripOption.forEach(function(tripElement) {
			
			var flightCarrier = tripElement.slice[0].segment[0].flight.carrier;
			var flightNumber = tripElement.slice[0].segment[0].flight.number;
			
			var originTerminal = tripElement.slice[0].segment[0].leg[0].originTerminal;
			var destinationTerminal = tripElement.slice[0].segment[0].leg[0].destinationTerminal;
	
			var origin = tripElement.slice[0].segment[0].leg[0].origin;
	
			var destination = tripElement.slice[0].segment[0].leg[0].destination;

			var time = tripElement.slice[0].segment[0].leg[0].duration;

		
			var depTime = tripElement.slice[0].segment[0].leg[0].departureTime;
		
			depTime = 	depTime.substring(depTime.indexOf("T")+1, depTime.indexOf("+"));

			var arrTime = tripElement.slice[0].segment[0].leg[0].arrivalTime;
		
			arrTime = 	arrTime.substring(arrTime.indexOf("T")+1, arrTime.indexOf("+"));

			var subtitle = origin + "-" + destination + " : " + time ;
			
			var title= flightCarrier +""+flightNumber + "  "  + depTime + "-" + arrTime;
	
			let element = {
				title: title,
				subtitle: subtitle,
				image_url:"https://facebook-chatbottnt.mybluemix.net/image.png"
			};

			if(flightElements.length <= 5)
				flightElements.push(element);
	
		}, this);

		console.log(flightElements);


		if(flightElements.length > 0 ){
			let attachment = {
				type : "template",
				payload : {
				 template_type:"generic",
				 //top_element_style:"Carousel",
				 elements: flightElements
			
					
				}
			};
	
			
	
			console.log("Channel is :"+ attachment);
	
			var messageData = {
				recipient: {
					id: channel
				},
				message: {
					attachment: attachment
				}	
		};
		setTimeout(function() {
			callSendAPI(messageData);
	}, 3000);
		;

		var location = getLocationCoordinatesForCity(destination);
		getWeatherForecastForCity(location, function(e, weatherOutput) {
			//	response.output.text[0] = weatherOutput;
				//callback(response);

				var weatherInformation = " Current Weather In " + destination + "\n Max Temp : " +  weatherOutput.forecasts[1].max_temp +
				"\n Min Temp :" + weatherOutput.forecasts[1].min_temp +
				" \n  " + weatherOutput.forecasts[1].narrative;

				var messageData = {
					recipient: {
						id: channel
					},
					message: {
						text: weatherInformation
					}	
			};
			setTimeout(function() {
				callSendAPI(messageData);
			}, 3000);
			;
			

		});

		
		}
	}else{
		var messageData = {
				recipient: {
					id: channel
				},
				message: {
					text: "Sorry. Not able to find flight for mentioned cities for selected date"
				}	
		};
		setTimeout(function() {
			callSendAPI(messageData);
	}, 3000);
		;
	}
	

	

}


function getLocationCoordinatesForCity(destination) {
	var location = {};
  var cityDetails =  airportCodeMap[destination.toLowerCase()][0];
	location.latitude = cityDetails.latitude;
	location.longitude = cityDetails.longitude;
	return location;
}

var weatherCompanyEndpoint = "https://b4ca6c28-e7c5-487f-a704-e81349a464db:Gvkw2Jpy4B@twcservice.mybluemix.net";// vcap.weatherinsights[0].credentials.url;


function getWeatherForecastForCity(location, callback) {
	var options = {
			url: weatherCompanyEndpoint + '/api/weather/v1/geocode/' + location.latitude + '/' + location.longitude + '/forecast/daily/3day.json'
	};
	request(
			options,
			function(error, response, body) {
					try {
							var json = JSON.parse(body);
							//console.log(json);
							var weatherOutput = json.forecasts[1].narrative;
							callback(null, json);
					} catch (e) {
							callback(e, null);
					}
			}
	);
};

function createFlightRequest(departure,destination,date){
	let request = {
		"request" :{
			"passengers" :{
				"kind" :"qpxexpress#passengerCounts",
				"adultCount" : 1,
				"infantInLapCount" :0,
				"infantInSeatCount":0,
				"childCount":0,
				"seniorCount":0,
			},
			"slice":[
				{
					"origin" :departure,
					"destination":destination,
					"maxStops":0,
					"date":date	
				}
			],
			"solution":2,
			"refundable":false
		}
	};
	console.log(JSON.stringify(request));
	return request;
}

function createPnrSearchJSON(pnrnumber, lastName){
	let request = {
			"recordLocator" : pnrnumber,
			"lastName": lastName,
			"searchType" : 'PNR'
		};
	
		console.log(JSON.stringify(request));
		return request;
}

function createItinerayTemplate(pnrNumber,lastName,message){
	
	//console.log("Inside createItinerayTemplate");
	var counterForTranid=12345;
	 request({
	  		uri: 'https://com-wci-ppe.us-south.containers.appdomain.cloud/v1/pnrsearch',
	  		method: 'POST',
	  		headers:  {
	  	        'Content-Type': 'application/json',
	  	        'tranid' : counterForTranid,
	  	        'sessionid' : 'abcxyz',
	  	        'appid' : 'EYWCI'
	  	      },
	  		json: createPnrSearchJSON(pnrNumber, lastName)

	  	}, function (error, response, body) {
	  		
	  		var error = 'error' in response.body || 'NO'
	  		//console.log("error" +error);
	  		//console.log("Response " +JSON.stringify(response));
	  		//console.log("Body" +JSON.stringify(body));
	  	
	  		if (error==="NO" && response.statusCode === 200) {
	  			var recipientId = body.recipient_id;
	  			var messageId = body.message_id;
	  			var transid=counterForTranid;
	  			createPNRcheckInIternity(response.body,message,transid);
	  		} else {
	  		var messageData = {
					recipient: {
						id: message.channel
					},
					message: {
						text: "Sorry. We can not find your PNR for checkin !!!"
					}	
			};
			setTimeout(function() {
				callSendAPI(messageData);
			}, 10000);	
	  		
	  		}
	  	});
	 
	counterForTranid++;
}

function createPNRcheckInIternity(body,message,tranid){
	//console.log("Inside createPNRcheckInIternity");
	
	if (body.openFlights.flights != 'undefined' && body.openFlights.flights.length == 0) {
		var messageData = {
				recipient: {
					id: message.channel
				},
				message: {
					text: "Sorry. You don't have any flight in next 48hrs !!!"
				}	
		};
		setTimeout(function() {
			callSendAPI(messageData);
		}, 10000);	
		
	}else{
		let test = {
				"type": "template",
				"payload": {
					"template_type": "airline_itinerary",
					"intro_message": "Here is your flight itinerary.",
					"locale": "en_US",
					"pnr_number": body.recordLocator,  //"HUHUHU"
					"passenger_info": [	],
					"flight_info": [ ],
					"passenger_segment_info": [],
					"base_price": "00000",  // Optional
					"tax": "000",		// OptionAL
					"total_price": "00000",
					"currency": "USD"
				}
		}
		
		
		//for each for all passenger info
		var passengerInfo= [];
		for (var key in body.openFlights.passengers) {
			var ordinal=body.openFlights.passengers[key].ordinal;
			var passengerId = ('00'+ordinal).slice(-3);
			console.log(passengerId);
			var passengerInfoObj = {
					"name": body.openFlights.passengers[key].firstName +" "+ body.openFlights.passengers[key].lastName,
					"ticket_number": body.openFlights.passengers[key].eticketNumber,
					"passenger_id": "p"+ passengerId
			}
			test.payload.passenger_info.push(passengerInfoObj)  //to add pass info
			passengerInfo.push(ordinal)
		}

		
		//for each for all flight info
		var flightInfo = [];
		for (var k in body.openFlights.flights) {
			var segmentId="s" + ('00'+(Number(body.openFlights.flights[k].ordinal) + 1)).slice(-3);
			var travelClass = checkFromTravelClassCode(body.openFlights.flights[k].bookingClassCode);
			//console.log("travelClass" +travelClass);
			var flightInfoObj = {
					"connection_id": "c001", //take increment value
					"segment_id": segmentId,  
					"flight_number": body.openFlights.flights[k].operatingCarrierCode + body.openFlights.flights[k].operatingCarrierNumber,
					"aircraft_type": body.openFlights.flights[k].aircraftType,
					"departure_airport": {
						"airport_code": body.openFlights.flights[k].departureAirportCode,
						"city": body.openFlights.flights[k].departureAirportCode, 
						"terminal": "XXX",  //ask
						"gate": "XX"		 //ask
					},
					"arrival_airport": {
						"airport_code": body.openFlights.flights[k].arrivalAirportCode,	
						"city": body.openFlights.flights[k].arrivalAirportCode,		
						"terminal": "XXX",	
						"gate": "XX"		
					},
					"flight_schedule": {
						"departure_time":  body.openFlights.flights[k].departureDate +"T"+ (body.openFlights.flights[k].departureEstimatedTime).slice(0,-2),
						"arrival_time": body.openFlights.flights[k].arrivalDate +"T"+ (body.openFlights.flights[k].arrivalEstimatedTime).slice(0,-2)
					},
					"travel_class": travelClass
			}
			test.payload.flight_info.push(flightInfoObj)  //to add pass info
			flightInfo.push(body.openFlights.flights[k].ordinal)
		}
		
		//for each for passenger segment info
		for (var p in body.openFlights.passengers) {    
			for(var q in body.openFlights.passengers[p].flights){ 
				var bookingSeatType = checkFromTravelClassCode(body.openFlights.passengers[p].flights[q].bookingClass);
				var passengerFlightOrdinal = body.openFlights.passengers[p].flights[q].ordinal;
				var passengerNo=passengerFlightOrdinal.slice(0,-2); 
				var segmentID="s" + ('00'+(Number(passengerFlightOrdinal.slice(-1)) + 1)).slice(-3);
				var passengerID="p" + ('00'+passengerNo).slice(-3);
				var passengerSegInfoObj = {
						"segment_id": segmentID,
						"passenger_id": passengerID,
						"seat":  body.openFlights.passengers[p].flights[q].seat,
						"seat_type": bookingSeatType
				}
				test.payload.passenger_segment_info.push(passengerSegInfoObj)  
			}
		}
		
		//console.log("Added all Info into test " +JSON.stringify(test));
		
		var messageData = {
			recipient: {
				id: message.channel
			},
			message: {
				attachment: test
			}	
		};
		//console.log("messageData" +JSON.stringify(messageData));
		message.watsonData.context["tranid"] = tranid;
		message.watsonData.context["passengerArray"] = passengerInfo;
		message.watsonData.context["flightArray"] = flightInfo;
		message.watsonData.context["phoneNumber"] = body.phoneNumber;
		message.watsonData.context["emailId"] = body.emailAddress;
		
		messageData.message.quick_replies  = createQuickRepliesForCheckIn();
		setTimeout(function() {
			callSendAPI(messageData);
		}, 10000);
	}
}

function checkFromTravelClassCode(bookingClassCode){
	//todo - can do uppercase of bookingClassCode for safer side
	var bookingClass;
	if(bookingClassCode != 'undefined' && (bookingClassCode=="T" || bookingClassCode=="E" || bookingClassCode=="V" ||
			bookingClassCode=="L" || bookingClassCode=="Q" || bookingClassCode=="M" || bookingClassCode=="K" ||
			bookingClassCode=="H" || bookingClassCode=="B" || bookingClassCode=="Y" || bookingClassCode=="N")){
		bookingClass = "Economy";
		console.log("Economy");
	}else if(bookingClassCode != 'undefined' && (bookingClassCode=="Z" || bookingClassCode=="W" || bookingClassCode=="D" ||
			bookingClassCode=="C" || bookingClassCode=="J" || bookingClassCode=="I")){
		bookingClass = "Business";
		console.log("Business");
	}else if(bookingClassCode != 'undefined' && (bookingClassCode=="R" || bookingClassCode=="A" || bookingClassCode=="F" ||
			bookingClassCode=="O")){
		bookingClass = "First";
		console.log("First");
	}else if(bookingClassCode != 'undefined' && (bookingClassCode=="P")){
		bookingClass = "The Residence";
		console.log("Residence");
	}
	return bookingClass; 
}

function createBoardingPassTemplate(tranid,passengerInfo,channel){	
	 request({
	  		uri: 'https://com-wci-ppe.us-south.containers.appdomain.cloud/v1/blocknpay ',
	  		method: 'POST',
	  		headers:{
	  	        'Content-Type': 'application/json',
	  	        'tranid' : '12345',
	  	        'sessionid' : 'abcxyz',
	  	        'appid' : 'EYWCI'
	  		},
	  		json: {
	  				"checkinDetailInfo": {
	  					"passengerOrdinals": passengerInfo,
	  					"flightOrdinal": "0"
	  	        	} 
	  			 }
	  	}, function (error, response, body) {
	  
  		var error = 'error' in response.body || 'NO'
  		//console.log("Response" +JSON.stringify(response));
  		console.log("Body" +JSON.stringify(body));
  		
  		if (error==="NO" && response.statusCode === 200) {
  			var recipientId = body.recipient_id;
  			var messageId = body.message_id;

  			if(body.processPaymentResponse.itinerary.passengers[0].checkinError != 'undefined' &&
  					body.processPaymentResponse.itinerary.passengers[0].checkinError != null){
  				var messageData = {
  						recipient: {
  							id: channel
  						},
  						message: {
  							text: body.processPaymentResponse.itinerary.passengers[0].checkinError.errorMessage
  						}	
  				};
  				setTimeout(function() {
  					callSendAPI(messageData);
  				}, 10000);	
  				
  			}else{
  				 createAirlineBoardingPassTemplate(body,channel);
  			}
  		} else {
  		
  		var messageData = {
				recipient: {
					id: channel
				},
				message: {
					text: error.errorMessage //"Unauthorized User / Session expired",
				}	
		};
		setTimeout(function() {
			callSendAPI(messageData);
		}, 10000);	
  		
  		}
  	});	  	
}
	  	
	  	

function createAirlineBoardingPassTemplate(body,channel){	

		let boardingPassTemplate =
		{
			"type": "template",
			"payload": {
			  "template_type": "airline_boardingpass",
			  "intro_message": "You are checked in.",
			  "locale": "en_US",
			  "boarding_pass": []
			}
		  }

		
	for(var obj in body.processPaymentResponse.boardingPasses){
		var boardingPass = {
				  "passenger_name": body.processPaymentResponse.boardingPasses[obj].firstName+"\/"+body.processPaymentResponse.boardingPasses[obj].lastName,
				  "pnr_number": body.processPaymentResponse.boardingPasses[obj].recordLocator,
				  "seat": body.processPaymentResponse.boardingPasses[obj].seatNumber,            
				  "logo_image_url": "https:\/\/www.example.com\/en\/logo.png",
				  "header_image_url": "https:\/\/www.example.com\/en\/fb\/header.png",
				  "qr_code": body.processPaymentResponse.boardingPasses[obj].barcode,
				  "above_bar_code_image_url": "https:\/\/www.example.com\/en\/PLAT.png",
				  "auxiliary_fields": [
					{
					  "label": "Terminal",
					  "value": "XXX" //blank from response
					},
					{
					  "label": "Departure",
					  "value": (body.processPaymentResponse.boardingPasses[obj].scheduledDepartureTime).slice(5,-11) 
					  			+"/"+(body.processPaymentResponse.boardingPasses[obj].scheduledDepartureTime).slice(8,-8) 
					  			+" "+(body.processPaymentResponse.boardingPasses[obj].scheduledDepartureTime).slice(11,-2)  //scheduledDepartureTime --need to update
					}
				  ],
				  "secondary_fields": [
					{
					  "label": "Boarding",
					  "value": (body.processPaymentResponse.boardingPasses[obj].boardTime).slice(10,-2)
					},
					{
					  "label": "Gate",
					  "value": "XXX"
					},
					{
					  "label": "Seat",
					  "value": body.processPaymentResponse.boardingPasses[obj].seatNumber
					},
					{
					  "label": "Sec.Nr.",
					  "value": "003"
					}
				  ],
				  "flight_info": {
					"flight_number": body.processPaymentResponse.boardingPasses[obj].carrierCode + body.processPaymentResponse.boardingPasses[obj].flightNumber,
					"departure_airport": {
					  "airport_code": body.processPaymentResponse.boardingPasses[obj].departureStationCode,
					  "city": body.processPaymentResponse.boardingPasses[obj].departureStationName,
					  "terminal": "XX",
					  "gate": "XXX"
					},
					"arrival_airport": {
					  "airport_code": body.processPaymentResponse.boardingPasses[obj].arrivalStationCode,
					  "city": body.processPaymentResponse.boardingPasses[obj].arrivalStationName
					},
					"flight_schedule": {
					  "departure_time":(body.processPaymentResponse.boardingPasses[obj].estimatedDepartureTime).slice(0,-8) + "T" + (body.processPaymentResponse.boardingPasses[obj].estimatedDepartureTime).slice(11,-2),// "2016-01-02T19:05",
					  "arrival_time": (body.processPaymentResponse.boardingPasses[obj].estimatedArrivalTime).slice(0,-8) + "T"+ (body.processPaymentResponse.boardingPasses[obj].estimatedArrivalTime).slice(11,-2) //"2016-01-05T17:30"
					}
				  }
				}
		boardingPassTemplate.payload.boarding_pass.push(boardingPass)  	
	}
		
		var messageData = {
				recipient: {
					id: channel
				},
				message: {
					attachment: boardingPassTemplate
				}	
			};
			//console.log("messageData" +JSON.stringify(messageData));
			messageData.message.quick_replies  = createQuickRepliesForShare();
			setTimeout(function() {
				callSendAPI(messageData);
			}, 10000);
		
}

function shareBoardingPassToWhatsapp(phNumber,paxArray,flightArray,tranid,channel){
	
	//var phnNum = "+91"+ (phNumber.slice(+3));
	 var indexOfPlus =  phNumber.indexOf("+");
	 var phoneNumber="+" + phNumber.slice(0,indexOfPlus) + phNumber.slice(indexOfPlus+1,phNumber.length);
	console.log("Phone number was " +phNumber+ " corrected phone number is "+ phoneNumber);
	 request({
	  		method: 'POST',
	  		headers:{
	  	        'Content-Type': 'application/json',
	  	        'tranid' : '12345',
	  	        'sessionid' : 'abcxyz',
	  	        'appid' : 'EYWCI'
	  		},
	  		json: {
	  			"phoneNumber": phoneNumber,
	  			"passengerOrdinals":paxArray,
	  			"flightOrdinals": flightArray
	  		}
	  	}, function (error, response, body) {
	  
		var error = 'error' in response.body || 'NO'
		//console.log("Response" +JSON.stringify(response));
		//console.log("Body" +JSON.stringify(body));

		if (error==="NO" && response.statusCode === 200) {
			var recipientId = body.recipient_id;
			var messageId = body.message_id;

				var messageData = {
						recipient: {
							id: channel
						},
						message: {
							text: "Sucessfully shared boarding pass to your number. Thank You !!"
						}	
				};
				
				//console.log("messageData" +JSON.stringify(messageData));
				
				setTimeout(function() {
					callSendAPI(messageData);
				}, 10000);	
		}else {
		var messageData = {
				recipient: {
					id: channel
				},
				message: {
					text: "Failed to share boarding pass to your number"
				}	
		};
		setTimeout(function() {
			callSendAPI(messageData);
		}, 10000);	
		
		}
	});	  	
}

function shareBoardingPassToEmail(emailId,paxArray,flightArray,tranid,channel){
	
	 request({
	  		uri: 'https://com-wci-ppe.us-south.containers.appdomain.cloud/v1/emailbp',
	  		method: 'POST',
	  		headers:{
	  	        'Content-Type': 'application/json',
	  	        'tranid' : '12345',
	  	        'sessionid' : 'abcxyz',
	  	        'appid' : 'EYWCI'
	  		},
	  		json: {
	  			"emailId": emailId,
	  			"passengerOrdinals":paxArray,
	  			"flightOrdinals": flightArray
	  		}
	  	}, function (error, response, body) {
	  
		var error = 'error' in response.body || 'NO'
		//console.log("Response" +JSON.stringify(response));
		
		if (error==="NO" && response.statusCode === 200) {
			var recipientId = body.recipient_id;
			var messageId = body.message_id;
				var messageData = {
						recipient: {
							id: channel
						},
						message: {
							text: "Sucessfully shared boarding pass to your Email Id. Thank You !!"
						}	
				};
				//console.log("messageData" +JSON.stringify(messageData));
				setTimeout(function() {
					callSendAPI(messageData);
				}, 10000);	
		}else {
			var messageData = {
					recipient: {
						id: channel
					},
					message: {
						text: "Failed to share boarding pass to your email Id"
					}	
			};
			setTimeout(function() {
				callSendAPI(messageData);
			}, 10000);	

		}
	});	  	
}


function createCheckInTemplate(pnrNumber){
	let checkInTemplate = {
		"type": "template",
		"payload": {
		  "template_type": "airline_checkin",
		  "intro_message": "Check-in is available now.",
		  "locale": "en_US",        
		  "pnr_number": pnrNumber,
		  "checkin_url":"http://www.moneycontrol.com",
		  "flight_info": [
			{
			  "flight_number": "f001",
			  "departure_airport": {
				"airport_code": "SFO",
				"city": "San Francisco",
				"terminal": "T4",
				"gate": "G8"
			  },
			  "arrival_airport": {
				"airport_code": "SEA",
				"city": "Seattle",
				"terminal": "T4",
				"gate": "G8"
			  },
			  "flight_schedule": {
				"boarding_time": "2016-01-05T15:05",
				"departure_time": "2016-01-05T15:45",
				"arrival_time": "2016-01-05T17:30"
			  }
			}
		  ]
		}
	  }

	  return checkInTemplate;
}


var watson = require('watson-developer-cloud');

var conversation = watson.conversation({
  username: process.env.CONVERSATION_USERNAME,
  password: process.env.CONVERSATION_PASSWORD,
  version: 'v1',
  version_date: '2017-05-26'
});

// Replace with the context obtained from the initial request
//var context = {};

function sendMessageToConversation(context){
	conversation.message({
		workspace_id: 'f3486a43-7dc3-4844-a063-97863db6965d',
		input: {'text': 'Proceed Check-in'},
		context: context
	  },  function(err, response) {
		if (err)
		  console.log('error:', err);
		else
		  console.log(JSON.stringify(response, null, 2));
	  });
}
